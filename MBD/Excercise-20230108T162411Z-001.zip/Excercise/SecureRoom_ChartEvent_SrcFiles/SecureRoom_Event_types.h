/*
 * File: SecureRoom_Event_types.h
 *
 * Code generated for Simulink model 'SecureRoom_Event'.
 *
 * Model version                  : 1.7
 * Simulink Coder version         : 8.10 (R2016a) 10-Feb-2016
 * C/C++ source code generated on : Mon Jan 02 18:58:31 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. ROM efficiency
 *    3. MISRA C:2012 guidelines
 * Validation result: Not run
 */

#ifndef RTW_HEADER_SecureRoom_Event_types_h_
#define RTW_HEADER_SecureRoom_Event_types_h_
#endif                                 /* RTW_HEADER_SecureRoom_Event_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
