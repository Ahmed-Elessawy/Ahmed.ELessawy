/*
 * File: SecureRoom_SubsystemTrigger_types.h
 *
 * Code generated for Simulink model 'SecureRoom_SubsystemTrigger'.
 *
 * Model version                  : 1.5
 * Simulink Coder version         : 8.10 (R2016a) 10-Feb-2016
 * C/C++ source code generated on : Mon Jan 02 19:13:55 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_SecureRoom_SubsystemTrigger_types_h_
#define RTW_HEADER_SecureRoom_SubsystemTrigger_types_h_

/* Forward declaration for rtModel */
typedef struct tag_RTM_SecureRoom_SubsystemT_T RT_MODEL_SecureRoom_Subsystem_T;

#endif                                 /* RTW_HEADER_SecureRoom_SubsystemTrigger_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
