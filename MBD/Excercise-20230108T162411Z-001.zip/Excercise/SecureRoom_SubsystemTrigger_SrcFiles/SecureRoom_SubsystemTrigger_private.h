/*
 * File: SecureRoom_SubsystemTrigger_private.h
 *
 * Code generated for Simulink model 'SecureRoom_SubsystemTrigger'.
 *
 * Model version                  : 1.5
 * Simulink Coder version         : 8.10 (R2016a) 10-Feb-2016
 * C/C++ source code generated on : Mon Jan 02 19:13:55 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_SecureRoom_SubsystemTrigger_private_h_
#define RTW_HEADER_SecureRoom_SubsystemTrigger_private_h_
#include "rtwtypes.h"
#endif                                 /* RTW_HEADER_SecureRoom_SubsystemTrigger_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
